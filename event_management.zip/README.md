# Event Management System (Django + DRF)

This is a minimal, working Django project with an `events` app implementing:
- UserProfile (linked to Django User)
- Event, RSVP, Review models
- JWT auth (Simple JWT)
- Event endpoints, RSVP and Reviews endpoints
- Example Celery task (needs Redis to run)

## Quick setup (local)

1. Create venv and activate it
2. pip install -r requirements.txt
3. python manage.py migrate
4. python manage.py createsuperuser
5. python manage.py runserver

JWT endpoints:
POST /api/token/  -> get access and refresh tokens
POST /api/token/refresh/ -> refresh access token

API base: /api/

Notes: This repo uses SQLite for simplicity.
