from rest_framework import serializers
from django.contrib.auth.models import User
from .models import UserProfile, Event, RSVP, Review

class SimpleUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username']

class UserProfileSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    email = serializers.EmailField(source='user.email', read_only=True)
    class Meta:
        model = UserProfile
        fields = ['username', 'email', 'full_name', 'bio', 'location', 'profile_picture']

class EventSerializer(serializers.ModelSerializer):
    organizer = SimpleUserSerializer(read_only=True)
    invited = SimpleUserSerializer(many=True, read_only=True)
    invited_ids = serializers.PrimaryKeyRelatedField(many=True, queryset=User.objects.all(), write_only=True, source='invited', required=False)

    class Meta:
        model = Event
        fields = ['id', 'title', 'description', 'organizer', 'location', 'start_time', 'end_time', 'is_public', 'invited', 'invited_ids', 'created_at', 'updated_at']
        read_only_fields = ['created_at', 'updated_at', 'organizer', 'invited']

    def create(self, validated_data):
        invited_users = validated_data.pop('invited', [])
        request = self.context.get('request')
        organizer = request.user
        event = Event.objects.create(organizer=organizer, **validated_data)
        if invited_users:
            event.invited.set(invited_users)
        return event

    def update(self, instance, validated_data):
        invited_users = validated_data.pop('invited', None)
        for attr, val in validated_data.items():
            setattr(instance, attr, val)
        instance.save()
        if invited_users is not None:
            instance.invited.set(invited_users)
        return instance

class RSVPSerializer(serializers.ModelSerializer):
    user = SimpleUserSerializer(read_only=True)
    class Meta:
        model = RSVP
        fields = ['id', 'event', 'user', 'status', 'created_at', 'updated_at']
        read_only_fields = ['created_at', 'updated_at', 'user']

class ReviewSerializer(serializers.ModelSerializer):
    user = SimpleUserSerializer(read_only=True)
    class Meta:
        model = Review
        fields = ['id', 'event', 'user', 'rating', 'comment', 'created_at']
        read_only_fields = ['created_at', 'user']
