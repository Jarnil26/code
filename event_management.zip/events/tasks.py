from celery import shared_task
from django.core.mail import send_mail
from django.conf import settings

@shared_task
def send_event_created_email(event_id, recipient_emails):
    from .models import Event
    try:
        event = Event.objects.get(pk=event_id)
    except Event.DoesNotExist:
        return
    subject = f"New Event Created: {event.title}"
    message = f"Event {event.title} scheduled from {event.start_time} to {event.end_time}."
    send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, recipient_emails)
