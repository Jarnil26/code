from django.urls import reverse
from rest_framework.test import APITestCase
from django.contrib.auth.models import User
from .models import Event

class EventAPITests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='alice', password='testpass')
        self.user2 = User.objects.create_user(username='bob', password='testpass2')

    def test_create_event(self):
        self.client.force_authenticate(user=self.user)
        url = reverse('event-list')
        data = {
            'title': 'Test Event',
            'description': 'Desc',
            'location': 'Venue',
            'start_time': '2030-01-01T10:00:00Z',
            'end_time': '2030-01-01T12:00:00Z',
            'is_public': True
        }
        resp = self.client.post(url, data, format='json')
        assert resp.status_code == 201

    def test_private_event_visibility(self):
        event = Event.objects.create(title='Private', organizer=self.user, start_time='2030-01-01T10:00Z', end_time='2030-01-01T12:00Z', is_public=False)
        event.invited.add(self.user2)
        self.client.force_authenticate(user=self.user2)
        url = reverse('event-detail', kwargs={'pk': event.id})
        resp = self.client.get(url)
        assert resp.status_code == 200
