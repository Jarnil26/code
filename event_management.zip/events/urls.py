from django.urls import path, include, re_path
from rest_framework.routers import DefaultRouter
from .views import EventViewSet, RSVPUpdateView, ReviewViewSet

router = DefaultRouter()
router.register(r'events', EventViewSet, basename='event')

urlpatterns = [
    path('', include(router.urls)),
    re_path(r'^events/(?P<event_pk>\d+)/rsvp/(?P<pk>\d+)/$', RSVPUpdateView.as_view({'patch': 'partial_update', 'get': 'retrieve'}), name='rsvp-detail'),
    re_path(r'^events/(?P<event_pk>\d+)/reviews/$', ReviewViewSet.as_view({'get': 'list', 'post': 'create'}), name='event-reviews'),
    re_path(r'^events/(?P<event_pk>\d+)/reviews/(?P<pk>\d+)/$', ReviewViewSet.as_view({'get': 'retrieve', 'put': 'update', 'delete': 'destroy', 'patch': 'partial_update'}), name='event-review-detail'),
]
