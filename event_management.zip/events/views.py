from rest_framework import viewsets, status, mixins
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAuthenticatedOrReadOnly
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from .models import Event, RSVP, Review
from .serializers import EventSerializer, RSVPSerializer, ReviewSerializer
from .permissions import IsOrganizerOrReadOnly, IsInvitedOrPublic
from django.shortcuts import get_object_or_404
from django.db import models

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [IsAuthenticatedOrReadOnly, IsOrganizerOrReadOnly]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['location', 'organizer__username', 'is_public']
    search_fields = ['title', 'location', 'description', 'organizer__username']
    ordering_fields = ['start_time', 'created_at']

    def get_queryset(self):
        qs = Event.objects.all()
        user = self.request.user
        if not user.is_authenticated:
            return qs.filter(is_public=True)
        return qs.filter(models.Q(is_public=True) | models.Q(invited=user) | models.Q(organizer=user)).distinct()

    def perform_create(self, serializer):
        serializer.save(organizer=self.request.user)

    def get_permissions(self):
        if self.action == 'retrieve':
            return [IsInvitedOrPublic()]
        return super().get_permissions()

    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated])
    def rsvp(self, request, pk=None):
        event = get_object_or_404(Event, pk=pk)
        if not event.is_public and not (request.user == event.organizer or event.invited.filter(id=request.user.id).exists()):
            return Response({'detail': 'You are not invited to this private event.'}, status=status.HTTP_403_FORBIDDEN)
        status_input = request.data.get('status', 'Going')
        rsvp, created = RSVP.objects.get_or_create(event=event, user=request.user, defaults={'status': status_input})
        if not created:
            rsvp.status = status_input
            rsvp.save()
        serializer = RSVPSerializer(rsvp, context={'request': request})
        return Response(serializer.data, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)

class RSVPUpdateView(mixins.UpdateModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    queryset = RSVP.objects.all()
    serializer_class = RSVPSerializer

    def get_object(self):
        event_id = self.kwargs.get('event_pk') or self.kwargs.get('event_id')
        user_id = self.kwargs.get('pk')
        return get_object_or_404(RSVP, event__id=event_id, user__id=user_id)

    def partial_update(self, request, *args, **kwargs):
        rsvp = self.get_object()
        if not (request.user == rsvp.user or request.user == rsvp.event.organizer):
            return Response({'detail': 'Not permitted'}, status=status.HTTP_403_FORBIDDEN)
        return super().partial_update(request, *args, **kwargs)

class ReviewViewSet(viewsets.ModelViewSet):
    serializer_class = ReviewSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['rating', 'user__username']
    search_fields = ['comment', 'user__username']

    def get_queryset(self):
        event_id = self.kwargs.get('event_pk') or self.kwargs.get('event_id') or self.request.query_params.get('event')
        if not event_id:
            return Review.objects.none()
        return Review.objects.filter(event__id=event_id)

    def perform_create(self, serializer):
        event_id = self.kwargs.get('event_pk') or self.kwargs.get('event_id')
        event = get_object_or_404(Event, pk=event_id)
        if not event.is_public and not (self.request.user == event.organizer or event.invited.filter(id=self.request.user.id).exists()):
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied("You are not allowed to review this private event.")
        serializer.save(user=self.request.user, event=event)
